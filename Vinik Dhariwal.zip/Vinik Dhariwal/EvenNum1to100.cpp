#include <iostream>
using namespace std;
int main() {
    int i;
    for (i = 2; i <= 100; i = i + 2) {
        cout << i << " ";
    }
    return 0;
}
