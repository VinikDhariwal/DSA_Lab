#include <iostream>
using namespace std;
int main(){
    int p,r,t,si;
    cout<<"Enter P R T: ";
    cin>>p>>r>>t;
    si=(p*r*t)/100;
    cout<<si;
    return 0;
}